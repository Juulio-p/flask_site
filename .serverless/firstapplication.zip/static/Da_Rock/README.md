# Da_Rock
Basic Rock Paper Scissors game. Using JavaScript
Part of prodject odin ciriculum--  https://www.theodinproject.com/paths/foundations/courses/foundations/lessons/revisiting-rock-paper-scissors
